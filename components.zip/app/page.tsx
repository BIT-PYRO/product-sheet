'use client'

import React from "react"

import { useState, useRef } from 'react'
import Image from 'next/image'

export default function ProductSheet() {
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [productImage, setProductImage] = useState<string | null>(null)

  const [platingType, setPlatingType] = useState([
    { id: 1, col1: '', col2: '', col3: '', col4: '', col5: '' },
    { id: 2, col1: '', col2: '', col3: '', col4: '', col5: '' },
    { id: 3, col1: '', col2: '', col3: '', col4: '', col5: '' },
  ])

  const [manufacturing, setManufacturing] = useState({
    dieNumber: '',
    process: '',
    images: '',
    notes: '',
  })

  const [others, setOthers] = useState([
    { id: 1, key: '', value: '' },
    { id: 2, key: '', value: '' },
    { id: 3, key: '', value: '' },
    { id: 4, key: '', value: '' },
    { id: 5, key: '', value: '' },
  ])

  const [sku, setSku] = useState('')
  const [listingName, setListingName] = useState('')
  const [material, setMaterial] = useState('')
  const [materialSku, setMaterialSku] = useState('')

  const [variations, setVariations] = useState([
    { id: 1, size: '', color: '' },
  ])

  const [stoneInfo, setStoneInfo] = useState([
    { id: 1, name: '', cut: '', color: '', size: '', quantity: '' },
    { id: 2, name: '', cut: '', color: '', size: '', quantity: '' },
    { id: 3, name: '', cut: '', color: '', size: '', quantity: '' },
    { id: 4, name: '', cut: '', color: '', size: '', quantity: '' },
  ])

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        setProductImage(event.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  // Handlers for Plating Type
  const updatePlatingType = (id: number, field: string, value: string) => {
    setPlatingType(
      platingType.map(row =>
        row.id === id ? { ...row, [field]: value } : row
      )
    )
  }

  const addPlatingTypeRow = () => {
    const newId = Math.max(...platingType.map(r => r.id), 0) + 1
    setPlatingType([
      ...platingType,
      { id: newId, col1: '', col2: '', col3: '', col4: '', col5: '' },
    ])
  }

  // Handlers for Others
  const updateOthers = (id: number, field: string, value: string) => {
    setOthers(
      others.map(row =>
        row.id === id ? { ...row, [field]: value } : row
      )
    )
  }

  const addOthersRow = () => {
    const newId = Math.max(...others.map(r => r.id), 0) + 1
    setOthers([...others, { id: newId, key: '', value: '' }])
  }

  // Handlers for Variations
  const updateVariation = (id: number, field: string, value: string) => {
    setVariations(
      variations.map(row =>
        row.id === id ? { ...row, [field]: value } : row
      )
    )
  }

  const addVariation = () => {
    const newId = Math.max(...variations.map(r => r.id), 0) + 1
    setVariations([...variations, { id: newId, size: '', color: '', single: true }])
  }

  // Handlers for Stone Info
  const updateStoneInfo = (id: number, field: string, value: string) => {
    setStoneInfo(
      stoneInfo.map(row =>
        row.id === id ? { ...row, [field]: value } : row
      )
    )
  }

  const addStoneInfoRow = () => {
    const newId = Math.max(...stoneInfo.map(r => r.id), 0) + 1
    setStoneInfo([
      ...stoneInfo,
      { id: newId, name: '', cut: '', color: '', size: '', quantity: '' },
    ])
  }

  return (
    <div className="min-h-screen bg-white p-4">
      <h1 className="text-xl font-bold text-center mb-6">PRODUCT SHEET</h1>

      {/* Top Section - Product Details & Variations Combined */}
      <div className="bg-gray-200 p-3 rounded-lg mb-6">
        <div className="flex gap-4 items-stretch">
          {/* Product Image - Left Side - 1/4 width */}
          <div
            className="w-1/4 bg-white border-2 border-gray-400 flex items-center justify-center flex-shrink-0 cursor-pointer hover:bg-gray-100 relative overflow-hidden"
            onClick={() => fileInputRef.current?.click()}
          >
            {productImage ? (
              <img
                src={productImage || "/placeholder.svg"}
                alt="Product"
                className="w-full h-full object-cover"
              />
            ) : (
              <span className="text-gray-600 text-center text-xs font-semibold">
                PRODUCT<br />IMAGE
              </span>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </div>

          {/* Product Details & Variations - Right Side - 3/4 width */}
          <div className="w-3/4">
            <div className="bg-white border-2 border-gray-400">
              {/* SKU Details Section */}
              <div className="border-b-2 border-gray-400 pb-1">
                <div className="flex border-b border-gray-400">
                  <div className="w-24 px-2 py-1 border-r-2 border-gray-400 font-semibold text-xs flex items-center flex-shrink-0">
                    SKU
                  </div>
                  <div className="flex-1 px-2 py-1">
                    <input
                      type="text"
                      value={sku}
                      onChange={(e) => setSku(e.target.value)}
                      className="w-full bg-transparent outline-none text-xs"
                    />
                  </div>
                </div>

                <div className="flex border-b border-gray-400">
                  <div className="w-24 px-2 py-1 border-r-2 border-gray-400 font-semibold text-xs flex items-center flex-shrink-0">
                    LISTING NAME
                  </div>
                  <div className="flex-1 px-2 py-1">
                    <input
                      type="text"
                      value={listingName}
                      onChange={(e) => setListingName(e.target.value)}
                      className="w-full bg-transparent outline-none text-xs"
                    />
                  </div>
                </div>

                <div className="flex border-b border-gray-400">
                  <div className="w-24 px-2 py-1 border-r-2 border-gray-400 font-semibold text-xs flex items-center flex-shrink-0">
                    MATERIAL
                  </div>
                  <div className="flex-1 px-2 py-1">
                    <input
                      type="text"
                      value={material}
                      onChange={(e) => setMaterial(e.target.value)}
                      className="w-full bg-transparent outline-none text-xs"
                    />
                  </div>
                </div>

                <div className="flex">
                  <div className="w-24 px-2 py-1 border-r-2 border-gray-400 font-semibold text-xs flex items-center flex-shrink-0">
                    MATERIAL SKU
                  </div>
                  <div className="flex-1 px-2 py-1">
                    <input
                      type="text"
                      value={materialSku}
                      onChange={(e) => setMaterialSku(e.target.value)}
                      className="w-full bg-transparent outline-none text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* Variations Section - with padding gap */}
              <div className="pt-1 border-t-2 border-gray-400">
                <div className="flex border-b border-gray-400">
                  <div className="w-24 px-2 py-1 border-r-2 border-gray-400 font-semibold text-xs flex items-center flex-shrink-0">
                    Variation
                  </div>
                  <div className="flex-1 px-2 py-1">
                    {/* Empty input for variation row */}
                  </div>
                </div>

                {variations.map((variation, index) => (
                  <div key={variation.id}>
                    {!variation.single ? (
                      <>
                        <div className="flex border-b border-gray-400">
                          <div className="w-24 px-2 py-1 border-r-2 border-gray-400 font-semibold text-xs flex items-center flex-shrink-0">
                            SIZE
                          </div>
                          <div className="flex-1 px-2 py-1">
                            <input
                              type="text"
                              value={variation.size}
                              onChange={(e) => updateVariation(variation.id, 'size', e.target.value)}
                              className="w-full bg-transparent outline-none text-xs"
                            />
                          </div>
                        </div>
                        <div className={`flex ${index < variations.length - 1 ? 'border-b border-gray-400' : ''}`}>
                          <div className="w-24 px-2 py-1 border-r-2 border-gray-400 font-semibold text-xs flex items-center flex-shrink-0">
                            COLOR
                          </div>
                          <div className="flex-1 px-2 py-1">
                            <input
                              type="text"
                              value={variation.color}
                              onChange={(e) => updateVariation(variation.id, 'color', e.target.value)}
                              className="w-full bg-transparent outline-none text-xs"
                            />
                          </div>
                        </div>
                      </>
                    ) : (
                      <div className={`flex ${index < variations.length - 1 ? 'border-b border-gray-400' : ''}`}>
                        <div className="w-24 px-2 py-1 border-r-2 border-gray-400 flex-shrink-0"></div>
                        <div className="flex-1 px-2 py-1">
                          <input
                            type="text"
                            value={variation.size}
                            onChange={(e) => updateVariation(variation.id, 'size', e.target.value)}
                            placeholder=""
                            className="w-full bg-transparent outline-none text-xs"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            <div
              className="px-2 py-1 bg-white border-x-2 border-b-2 border-gray-400 rounded-b-lg cursor-pointer hover:bg-gray-50 text-xs font-semibold"
              onClick={addVariation}
            >
              + ADD Variation
            </div>
          </div>
        </div>
      </div>

      {/* New Panel - Placeholder */}
      <div className="bg-gray-200 p-3 rounded-lg mb-6">
        <div className="bg-white border-2 border-gray-400 p-3">
          {/* Content goes here (minimal) */}
        </div>
      </div>

      {/* Stone Info Section */}
      <div className="bg-gray-200 p-6 rounded-lg mb-8">
        <h2 className="text-sm font-semibold mb-6">STONE INFO</h2>
        <div className="bg-white">
          <table className="w-full border-2 border-gray-400">
            <thead>
              <tr className="border-b-2 border-gray-400">
                <th className="w-32 px-2 py-1.5 text-left font-semibold text-xs border-r-2 border-gray-400 bg-white">
                  NAME
                </th>
                <th className="w-32 px-2 py-1.5 text-left font-semibold text-xs border-r-2 border-gray-400 bg-white">
                  CUT
                </th>
                <th className="w-32 px-2 py-1.5 text-left font-semibold text-xs border-r-2 border-gray-400 bg-white">
                  COLOR
                </th>
                <th className="w-32 px-2 py-1.5 text-left font-semibold text-xs border-r-2 border-gray-400 bg-white">
                  SIZE
                </th>
                <th className="w-32 px-2 py-1.5 text-left font-semibold text-xs bg-white">
                  QUANTITY
                </th>
              </tr>
            </thead>
            <tbody>
              {stoneInfo.map((stone, index) => (
                <tr key={stone.id} className={index < stoneInfo.length - 1 ? 'border-b-2 border-gray-400' : ''}>
                  <td className="w-32 px-2 py-1.5 border-r-2 border-gray-400 bg-white">
                    <input
                      type="text"
                      value={stone.name}
                      onChange={(e) => updateStoneInfo(stone.id, 'name', e.target.value)}
                      className="w-full bg-transparent outline-none text-sm"
                    />
                  </td>
                  <td className="w-32 px-2 py-1.5 border-r-2 border-gray-400 bg-white">
                    <input
                      type="text"
                      value={stone.cut}
                      onChange={(e) => updateStoneInfo(stone.id, 'cut', e.target.value)}
                      className="w-full bg-transparent outline-none text-sm"
                    />
                  </td>
                  <td className="w-32 px-2 py-1.5 border-r-2 border-gray-400 bg-white">
                    <input
                      type="text"
                      value={stone.color}
                      onChange={(e) => updateStoneInfo(stone.id, 'color', e.target.value)}
                      className="w-full bg-transparent outline-none text-sm"
                    />
                  </td>
                  <td className="w-32 px-2 py-1.5 border-r-2 border-gray-400 bg-white">
                    <input
                      type="text"
                      value={stone.size}
                      onChange={(e) => updateStoneInfo(stone.id, 'size', e.target.value)}
                      className="w-full bg-transparent outline-none text-sm"
                    />
                  </td>
                  <td className="w-32 px-2 py-1.5 bg-white">
                    <input
                      type="text"
                      value={stone.quantity}
                      onChange={(e) => updateStoneInfo(stone.id, 'quantity', e.target.value)}
                      className="w-full bg-transparent outline-none text-sm"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div
            className="px-2 py-1.5 bg-white border-x-2 border-b-2 border-gray-400 rounded-b-lg text-xs font-semibold cursor-pointer hover:bg-gray-50"
            onClick={addStoneInfoRow}
          >
            +ADD ROW
          </div>
        </div>
      </div>

      {/* Plating Type Section */}
      <div className="bg-gray-200 p-6 rounded-lg mb-8">
        <h2 className="text-sm font-semibold mb-3">PLATING TYPE</h2>
        <div className="bg-white">
          <table className="w-full border-2 border-gray-400">
            <thead>
              <tr className="border-b-2 border-gray-400">
                <th className="w-32 px-2 py-1.5 text-left font-semibold text-xs border-r-2 border-gray-400 bg-white"></th>
                <th className="w-32 px-2 py-1.5 text-left font-semibold text-xs border-r-2 border-gray-400 bg-white"></th>
                <th className="w-32 px-2 py-1.5 text-left font-semibold text-xs border-r-2 border-gray-400 bg-white"></th>
                <th className="w-32 px-2 py-1.5 text-left font-semibold text-xs bg-white"></th>
              </tr>
            </thead>
            <tbody>
              {platingType.map((row, index) => (
                <tr key={row.id} className={index < platingType.length - 1 ? 'border-b-2 border-gray-400' : ''}>
                  <td className="w-32 px-2 py-1.5 border-r-2 border-gray-400 bg-white">
                    <input
                      type="text"
                      value={row.col2}
                      onChange={(e) => updatePlatingType(row.id, 'col2', e.target.value)}
                      className="w-full bg-transparent outline-none text-sm"
                    />
                  </td>
                  <td className="w-32 px-2 py-1.5 border-r-2 border-gray-400 bg-white">
                    <input
                      type="text"
                      value={row.col3}
                      onChange={(e) => updatePlatingType(row.id, 'col3', e.target.value)}
                      className="w-full bg-transparent outline-none text-sm"
                    />
                  </td>
                  <td className="w-32 px-2 py-1.5 border-r-2 border-gray-400 bg-white">
                    <input
                      type="text"
                      value={row.col4}
                      onChange={(e) => updatePlatingType(row.id, 'col4', e.target.value)}
                      className="w-full bg-transparent outline-none text-sm"
                    />
                  </td>
                  <td className="w-32 px-2 py-1.5 bg-white">
                    <input
                      type="text"
                      value={row.col5}
                      onChange={(e) => updatePlatingType(row.id, 'col5', e.target.value)}
                      className="w-full bg-transparent outline-none text-sm"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div
          className="px-2 py-1.5 bg-white border-x-2 border-b-2 border-gray-400 rounded-b-lg text-xs font-semibold cursor-pointer hover:bg-gray-50"
          onClick={addPlatingTypeRow}
        >
          +ADD ROWS
        </div>
      </div>

      {/* Manufacturing Section */}
      <div className="bg-gray-200 p-6 rounded-lg mb-8">
        <h2 className="text-sm font-semibold mb-3">MANUFACTURING</h2>
        <div className="bg-white">
          <div className="border-2 border-gray-400">
            <div className="flex border-b-2 border-gray-400">
              <div className="w-24 p-2 border-r-2 border-gray-400 font-semibold text-sm bg-white flex-shrink-0">
                DIE NUMBER
              </div>
              <div className="flex-1 p-2 bg-white">
                <input
                  type="text"
                  value={manufacturing.dieNumber}
                  onChange={(e) =>
                    setManufacturing({ ...manufacturing, dieNumber: e.target.value })
                  }
                  className="w-full bg-transparent outline-none text-sm"
                />
              </div>
            </div>

            <div className="flex border-b-2 border-gray-400">
              <div className="w-24 p-2 border-r-2 border-gray-400 font-semibold text-sm bg-white flex-shrink-0">
                PROCESS
              </div>
              <div className="flex-1 p-2 bg-white">
                <input
                  type="text"
                  value={manufacturing.process}
                  onChange={(e) =>
                    setManufacturing({ ...manufacturing, process: e.target.value })
                  }
                  className="w-full bg-transparent outline-none text-sm"
                />
              </div>
            </div>

            <div className="flex border-b-2 border-gray-400">
              <div className="w-24 p-2 border-r-2 border-gray-400 font-semibold text-sm bg-white flex-shrink-0">
                IMAGES
              </div>
              <div className="flex-1 p-2 bg-white">
                <input
                  type="text"
                  value={manufacturing.images}
                  onChange={(e) =>
                    setManufacturing({ ...manufacturing, images: e.target.value })
                  }
                  className="w-full bg-transparent outline-none text-sm"
                />
              </div>
            </div>

            <div className="flex border-b-2 border-gray-400">
              <div className="w-24 p-2 border-r-2 border-gray-400 font-semibold text-sm bg-white flex-shrink-0">
                NOTES
              </div>
              <div className="flex-1 p-2 bg-white">
                <input
                  type="text"
                  value={manufacturing.notes}
                  onChange={(e) =>
                    setManufacturing({ ...manufacturing, notes: e.target.value })
                  }
                  className="w-full bg-transparent outline-none text-sm"
                />
              </div>
            </div>

          </div>
        </div>
        <div
          className="p-3 bg-white border-x-2 border-b-2 border-gray-400 rounded-b-lg text-sm font-semibold cursor-pointer hover:bg-gray-50"
          onClick={() => {}}
        >
          +ADD ROW
        </div>
      </div>

    </div>
  )
}
